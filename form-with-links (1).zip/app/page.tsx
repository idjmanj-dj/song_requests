"use client"

import SongRequestForm from "../song-request-form"

export default function Page() {
  return <SongRequestForm />
}
