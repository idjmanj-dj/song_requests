"use client"

import DJDashboard from "../../dj-dashboard"

export default function DashboardPage() {
  return <DJDashboard />
}
